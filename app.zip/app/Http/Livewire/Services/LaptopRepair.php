<?php

namespace App\Http\Livewire\Services;

use Livewire\Component;

class LaptopRepair extends Component
{
    public function render()
    {
        return view('livewire.services.laptop-repair')->layout('layouts.page');
    }
}
