<?php

namespace App\Http\Livewire\Services;

use Livewire\Component;

class PCRepair extends Component
{
    public function render()
    {
        return view('livewire.services.p-c-repair')->layout('layouts.page');
    }
}
