<?php

namespace App\Http\Livewire\Services;

use Livewire\Component;

class MacRepair extends Component
{
    public function render()
    {
        return view('livewire.services.mac-repair')->layout('layouts.page');
    }
}
