<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>

    <table rules="all" style="border-style: solid; border-color: #666;" cellpadding="10">
        <thead>
            <tr style='background: #eee;'>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>message</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($data['name']); ?></td>
                <td><?php echo e($data['email']); ?></td>
                <td><?php echo e($data['contact']); ?></td>
                <td><?php echo e($data['message']); ?></td>
            </tr>
        </tbody>
    </table>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\bethel-new\resources\views/emails/contactEmail.blade.php ENDPATH**/ ?>