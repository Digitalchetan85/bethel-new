<div>
    <!-- Content  -->
	<div id="page-content">
		<!-- Breadcrumbs Block -->
		<div class="block" id="bread">
			<div class="container">
				<div class="breadcrumbs">
					<ul class="breadcrumb">
						<li><a href="{{route('home')}}">Home</a></li>
						<li class="active">About Us</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- //Breadcrumbs Block -->

        <div class="block mt-0">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-lg-3">
						<ul class="service-list-1">
							<li class="active"><a href="service-page-1.html">Laptop Repair</a></li>
							<li><a href="service-page-2.html">PC Repair</a></li>
							<li><a href="service-page-3.html">Mac Repair</a></li>
							<li><a href="service-page-4.html">Data Backup and Recovery</a></li>
							<li><a href="service-page-5.html">Malware and Virus Removal</a></li>
							<li><a href="service-page-6.html">Software Installation</a></li>
							<li><a href="service-page-7.html">Hardware Updates</a></li>
							<li><a href="service-page-8.html">Custom Built Computers</a></li>
							<li><a href="service-page-9.html">Network / Servers</a></li>
						</ul>
						<a class="btn btn-full text-left modal-popup-link" href="#modalForm1"><i class="icon-music-social-group"></i>Book an engineer</a>
						<div class="form-popup-wrap form-popup-wrap-full">
							<a href="" class="btn btn-full btn-invert text-left form-popup-link"><i class="icon-diag"></i>Get a Quote</a>
							<div class="form-popup form-popup--left">
								<div class="quote-form">
									<form id="quoteform2" class="quote-form-js" method="post" novalidate>
										<div class="successform">
											<p>Your message was sent successfully!</p>
										</div>
										<div class="errorform">
											<p>Something went wrong, try refreshing and submitting the form again.</p>
										</div>
										<div class="wrapper">
											<div class="input-half pull-left">
												<input type="text" placeholder="Name" name="name">
											</div>
											<div class="input-half pull-right">
												<input type="text" placeholder="Email Address" name="email">
											</div>
										</div>
										<input type="text" placeholder="Phone" name="phone" class="input-full">
										<textarea placeholder="Message" name="message" class="input-full"></textarea>
										<button type="submit" id="submit2" class="btn">Get a Quote</button>
									</form>
								</div>
							</div>
						</div>
						<div class="contact-box">
							<div class="contact-box-row">
								<i class="icon-phone-receiver"></i>
								<div class="contact-box-row-title"><b>Contact Phone</b></div>
								<div>+91 88804 70007</div>
							</div>
							<div class="contact-box-row">
								<i class="icon-placeholder-for-map"></i>
								<div class="contact-box-row-title"><b>Office Address</b></div>
								<div>5604 Willow Crossing Ct, Clifton, VA, 20124</div>
							</div>
							<div class="contact-box-row">
								<i class="icon-clock"></i>
								<div class="contact-box-row-title"><b>Office hours</b></div>
								<div>Mon - Fri: 7:00am - 7:00pm
									<br> Sat - Sun: 10:00am - 5:00pm</div>
							</div>
						</div>
						<div class="question-box">
							<div class="question-box-title">ASK A QUESTION</div>
							<form class="question-form" method="post">
								<div class="successform">
									<p>Your message was sent successfully!</p>
								</div>
								<div class="errorform">
									<p>Something went wrong, try refreshing and submitting the form again.</p>
								</div>
								<input type="text" name="name" class="form-control" value="" placeholder="Your name">
								<input type="text" name="email" class="form-control" value="" placeholder="Your email">
								<textarea name="message" class="form-control" placeholder="Your question"></textarea>
								<div class="clearfix">
									<button type="submit" id="submitQuestion" class="btn btn-full">Send</button>
								</div>
							</form>
						</div>
					</div>
					<div class="divider-lg visible-xs"></div>
					<div class="col-md-8 col-lg-9">
						<h1>Software <span class="color">Installation</span></h1>
						<div><img src="<?php echo e(asset('assets/images/img-service-6.jpg')); ?>" class="img-responsive" alt=""></div>
						<div class="divider-lg"></div>
						<p><b>There are all kinds of software in the market for each and every one of your needs. Installation and setup can be stressful for those who aren’t techy. However, you no longer have to worry about the installation of the software you need.</b> </p>
						<p>Whatever project you’re working on – from building web pages to building football stadiums – you’re going to need the right sort of software to handle the job.</p>
						<p>There are two types: System software is what runs and manages your computer, such as your operating system or file management utilities. Application software, popularly known as apps, refers to software that allows users to complete specific tasks.</p>
						<div class="divider"></div>
						<h4 class="no-upper">Help Is A Phone Call Away</h4>
						<ul class="marker-list-md-1">
							<li><b>Determine Computer Compatibility For The Install</b> – Some software works with some computers, but software programs are not necessarily universal. Our Expert Techs will determine if your computer is compatible with the software you are considering.</li>
							<li><b>Install And Configure Software</b> – If the software and your computer are a match, we will install it for you. Settings will be configured to make it as easy as possible to use.</li>
							<li><b>Perform Necessary Software Updates</b> – If your software was purchased in a store and came out of a box, it might well be out of date. Developers regularly release updates for their software, and packaged software probably will not be the latest version. Your Expert Techs will take care of that, downloading and installing the latest updates.</li>
							<li><b>Create Required Shortcuts</b> – We will also create desktop, start menu, and quick launch shortcuts, making your new software easily accessible.</li>
						</ul>
						<p>Before we abandon you to your new, exciting installed software program, we’ll make sure you know how to use it. Don’t worry.</p>
						<div class="divider"></div>
						<h4 class="no-upper">Business Software Install</h4>
						<p>Businesses without their own IT department will benefit from Jim’s famous ‘worry free’ service, too. Jim’s can handle software requirements for any size business. Whether your business needs a few applications on one or two computers or many apps installed in several places on multiple devices, Jim’s will make sure your business’ software is headache-free.</p>
						<p>Home or business, large or small, simple or complicated, Jim’s famous ‘worry free’ service takes the guesswork out of software installation.</p>
					</div>
				</div>
			</div>
		</div>

		<!-- Get Now Block -->
		<div class="block bg-light full-block bottom-null">
			<div class="container">
				<div class="text-center">
					<h2 class="h-lg">Get <span class="color">Your Computer</span> Fixed NOW!</h2>
					<h3 class="subtitle">+91 98800 37944 / 88804 70007</h3>
					<p class="info">for one of our professional computer repair techs to help you with your Desktop, Laptop, Mac or other inquiry</p>
					<div class="btn-inline">
						<div class="form-popup-wrap">
							<a href="#" class="btn form-popup-link">Free Estimate</a>
							<div class="form-popup">
								<div class="quote-form">
									<form id="quoteform2" class="quote-form-js" method="post" novalidate>
										<div class="successform">
											<p>Your message was sent successfully!</p>
										</div>
										<div class="errorform">
											<p>Something went wrong, try refreshing and submitting the form again.</p>
										</div>
										<div class="wrapper">
											<div class="input-half pull-left">
												<input type="text" placeholder="Name" name="name">
											</div>
											<div class="input-half pull-right">
												<input type="text" placeholder="Email Address" name="email">
											</div>
										</div>
										<input type="text" placeholder="Phone" name="phone" class="input-full">
										<textarea placeholder="Message" name="message" class="input-full"></textarea>
										<button type="submit" id="submit2" class="btn">Get a Quote</button>
									</form>
								</div>
							</div>
						</div>
						<a class="btn btn-invert" href="contact.html">Contact Us</a></div>
				</div>
			</div>
		</div>
		<!-- //Get Now Block -->
	</div>
	<!-- // Content  -->
</div>
<?php /**PATH C:\xampp\htdocs\bethel-new\resources\views/livewire/services/software-installation.blade.php ENDPATH**/ ?>