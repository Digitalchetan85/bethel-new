<div>
    
</div>
<?php /**PATH C:\xampp\htdocs\bethel-new\resources\views/livewire/admin/products-component.blade.php ENDPATH**/ ?>