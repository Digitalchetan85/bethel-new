<div>
    <style>
        nav {
            text-align: center;
        }

        nav svg {
            height: 10px;
        }

        nav .hidden {
            display: block !important;
        }

        .select-none {
            margin-right: 5px !important;
        }

    </style>
    <!-- Content  -->
	<div id="page-content">
		<!-- Breadcrumbs Block -->
		<div class="block" id="bread">
			<div class="container">
				<div class="breadcrumbs">
					<ul class="breadcrumb">
						<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
						<li class="active">Desktop</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- //Breadcrumbs Block -->

        <div class="block mt-0">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-lg-3">
						<div class="">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sidemenu', [])->html();
} elseif ($_instance->childHasBeenRendered('l4047753490-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4047753490-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4047753490-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4047753490-0');
} else {
    $response = \Livewire\Livewire::mount('sidemenu', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4047753490-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
					</div>
					<div class="divider-lg visible-xs"></div>
					<div class="col-md-8 col-lg-9">
                        
						<div class="row">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <a href="<?php echo e(route('product.details', ['slug' => $product->slug])); ?>">
                                        <div class="">
                                            <img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($product->image); ?>"
                                                class="img-responsive" alt="...">
                                            <p class="text-center text-primary"><?php echo e($product->name); ?></p>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="text-center">
                            <?php echo e($products->links()); ?>

                        </div>
					</div>
				</div>
			</div>
		</div>

		<div id="similar-products" class="py-3 py-md-5">
            <div class="container">
                <h2 class="text-primary py-3 text-center">Related Products</h2>
                <div class="row">
                    <?php $__currentLoopData = $relatedproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <a href="<?php echo e(route('product.details', ['slug' => $product->slug])); ?>">
                                <div class="item">
                                    <div class="text-center">
                                        <img src="<?php echo e(asset('/assets/images/products')); ?>/<?php echo e($product->image); ?>"
                                            alt="" class="pb-2 img-responsive">
                                        <p><?php echo e($product->name); ?></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

		<!-- Get Now Block -->
		<div class="block bg-light full-block bottom-null">
			<div class="container">
				<div class="text-center">
					<h2 class="h-lg">Get <span class="color">Your Computer</span> Fixed NOW!</h2>
					<h3 class="subtitle">+91 98800 37944 / 88804 70007</h3>
					<p class="info">for one of our professional computer repair techs to help you with your Desktop, Laptop, Mac or other inquiry</p>
					<div class="btn-inline">
							
						<a class="btn btn-invert" href="<?php echo e(route('contact')); ?>">Contact Us</a></div>
				</div>
			</div>
		</div>
		<!-- //Get Now Block -->
    </div>
</div><?php /**PATH C:\xampp\htdocs\bethel-new\resources\views/livewire/desktop-component.blade.php ENDPATH**/ ?>