<div>
    <!-- Content  -->
	<div id="page-content">
		<!-- Breadcrumbs Block -->
		<div class="block" id="bread">
			<div class="container">
				<div class="breadcrumbs">
					<ul class="breadcrumb">
						<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
						<li class="active">About Us</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- //Breadcrumbs Block -->
		<!-- Category Block -->
		<div class="block">
			<div class="container">
				<h1 class="text-center">About <span class="color">Us</span></h1>
				<p class="info text-center">Your Local Computer Specialist Servicing</p>
				<p class="text-center">Computer Repair is dedicated to providing the best customer service and computer repair available to you. When your Laptop, PC or Mac needs repairing, you won’t have to worry for long! Our technicians are skilled in dealing with all computers and gadgets whether you need home or business computer repairs.</p>
				<div class="row">
					<div class="col-sm-5 col-lg-5 col-lg-offset-1">
						<ul class="marker-list-sm animation" data-animation="fadeInLeft" data-animation-delay="0s">
							<li>Microsoft Windows PC Computer Repair</li>
							<li>Apple iMac and Macbook Computer Repair</li>
							<li>Data Recovery</li>
							<li>Viruses, Malware, Adware and Ransom-ware Removal</li>
							<li>Cracked and Broken Laptop Screen Replacements</li>
						</ul>
					</div>
					<div class="col-sm-5 col-lg-5 col-lg-offset-1">
						<ul class="marker-list-sm animation" data-animation="fadeInRight" data-animation-delay="0s">
							<li>Microsoft Windows PC Computer Repair</li>
							<li>Apple iMac and Macbook Computer Repair</li>
							<li>Data Recovery</li>
							<li>Viruses, Malware, Adware and Ransom-ware Removal</li>
							<li>Cracked and Broken Laptop Screen Replacements</li>
						</ul>
					</div>
				</div>
				<div class="divider-xl"></div>
				<h3 class="text-center">Our Advantages</h3>
				<div class="divider"></div>
				<div class="row">
					<div class="col-sm-6 col-md-3">
						<div class="row-icon">
							<div class="row-icon-icon"><i class="icon-placeholder-for-map"></i></div>
							<div class="row-icon-text">
								Any Place
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-3">
						<div class="row-icon">
							<div class="row-icon-icon"><i class="icon-repair"></i></div>
							<div class="row-icon-text">
								Any Screen Size
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-3">
						<div class="row-icon">
							<div class="row-icon-icon"><i class="icon-prize-badge-with-star-and-ribbon"></i></div>
							<div class="row-icon-text">
								Quality Parts Only
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-3">
						<div class="row-icon">
							<div class="row-icon-icon"><i class="icon-calendar"></i></div>
							<div class="row-icon-text">
								7 Days a Week
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="block bg-lighter full-block bottom-null ">
			<div class="container">
				<div class="hexagon-box-wrapper">
					<div class="hexagon-box">
						<div class="hexagon-icon"><i class="icon-computer-with-monitor"></i>
							<div class="h-box">
								<div class="h-box-title">PC Repair</div>
								<div class="h-box-text">Problem PC? We’ll solve it. We’re who you call when your desktop runs slow and your programs stop working. </div>
							</div>
						</div>
						<div class="hexagon-icon"><i class="icon-apple"></i>
							<div class="h-box">
								<div class="h-box-title">Mac Repair</div>
								<div class="h-box-text">Our Mac repair service offers high-quality repairs and advice: without the premium price.</div>
							</div>
						</div>
						<div class="hexagon-icon"><i class="icon-updated-security-for-protection-on-internet"></i>
							<div class="h-box">
								<div class="h-box-title">Data Backup & Recovery</div>
								<div class="h-box-text">We can help you back up your important personal data (photos, videos, documents, school work, etc.) to disk and cloud with no hassles.</div>
							</div>
						</div>
						<div class="hexagon-icon visible-xs">
							<img src="<?php echo e(asset('assets/images/h-bg.png')); ?>" alt="">
						</div>
						<div class="hexagon-icon"><i class="icon-data-network"></i>
							<div class="h-box">
								<div class="h-box-title">Network / Servers</div>
								<div class="h-box-text">Our technicians can set up a secure wireless network in your home that will allow you to share everything between as many computers</div>
							</div>
						</div>
						<div class="hexagon-icon"><i class="icon-viruses"></i>
							<div class="h-box">
								<div class="h-box-title">Malware and Virus Removal
								</div>
								<div class="h-box-text">Through years of experience we can remove the infestation without destroying your data. </div>
							</div>
						</div>
						<div class="hexagon-icon"><i class="icon-notebook-and-mouse-cursor"></i>
							<div class="h-box">
								<div class="h-box-title">Laptop Repair </div>
								<div class="h-box-text">Laptop gone down? Don’t worry! Our qualified, friendly laptop repair technicians will bring it back to life. </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Services Block -->
		
		<!-- //Services Block -->
		<!-- Team Block -->
		
		<!-- //Team Block -->
		<!-- Block -->
		
		<!-- //Block -->
		<!-- Get Now Block -->
		<div class="block bg-light full-block bottom-null">
			<div class="container">
				<div class="text-center">
					<h2 class="h-lg">Get <span class="color">Your Computer</span> Fixed NOW!</h2>
					<h3 class="subtitle">+91 98800 37944 / 88804 70007</h3>
					<p class="info">for one of our professional computer repair techs to help you with your Desktop, Laptop, Mac or other inquiry</p>
					<div class="btn-inline">
							
						<a class="btn btn-invert" href="<?php echo e(route('contact')); ?>">Contact Us</a></div>
				</div>
			</div>
		</div>
		<!-- //Get Now Block -->
	</div>
	<!-- // Content  -->
</div>
<?php /**PATH C:\xampp\htdocs\bethel-new\resources\views/livewire/about-component.blade.php ENDPATH**/ ?>